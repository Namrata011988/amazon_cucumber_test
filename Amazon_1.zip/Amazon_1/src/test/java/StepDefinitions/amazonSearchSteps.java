package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import static org.junit.Assert.assertTrue;

public class amazonSearchSteps {

	private static final String NONE = "none";
	WebDriver driver;
	
	@Given("^user launches the amazon (.*)")
	public void user_launches_the_amazon_amazon_com(String webpage) throws Throwable{

		driver = getDriver();	
		driver.get(webpage);
		driver.manage().window().maximize();

	}

	@And("enters Nikon in the search bar")
	public void enters_Nikon_in_the_search_bar() throws Throwable{
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Nikon");
		driver.findElement(By.id("nav-search-submit-button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("sort results for higher to lower price")
	public void sort_results_for_higher_to_lower_price() throws Throwable{
		
//		Using the Select selenium option
//		WebElement element = driver.findElement(By.xpath("//*[@id=\"s-result-sort-select\"]"));
//		Select select = new Select(element);
//		select.selectByValue("price-desc-rank");
		
//		Using direct selenium methods
//		driver.findElement(By.id("a-autoid-0-announce")).click();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		driver.findElement(By.id("s-result-sort-select_2")).click();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
//		Using javascript executor
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement sortElement = driver.findElement(By.id("a-autoid-0-announce"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", sortElement);
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement highToLowElement = driver.findElement(By.id("s-result-sort-select_2"));
		executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", highToLowElement);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Then("selects the second product for details")
	public void selects_the_second_product_for_details() throws Throwable{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("img[data-image-index^='1']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Then("verify the product details contain Nikon specifications")
	public void verify_the_product_details_contain_Nikon_specifications() throws Throwable{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String productTile = driver.findElement(By.id("productTitle")).getText();
		assertTrue(productTile + ":" + "Product title does not contain Nikon D3X", productTile.toLowerCase().contains("Nikon D3X"));
	}

	
//	To read from the configuration/commandline attribute
    public static String getConfigValue(String key, String defaultValue) {
		final String systemProp = System.getProperty(key);
		if (systemProp != null) {
			return systemProp;
		}
		
		final String envVar = System.getenv(key);
		if (envVar != null) {
			return envVar;
		}
		
		return defaultValue;
	}
	
	private WebDriver getDriver() {
		
		String browserName = getConfigValue("browser",NONE);
		final String chromeDriverLocation = getConfigValue("chrome_driver_location", NONE);
		final String firefoxDriverLocation = getConfigValue("gecko_driver_location",NONE);

		
		if(browserName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driverr", firefoxDriverLocation);
			driver = new FirefoxDriver();
		}
		else if(browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driverr", chromeDriverLocation);
			driver = new ChromeDriver();
		}
		else {
			System.setProperty("webdriver.gecko.driverr", firefoxDriverLocation);
			driver = new FirefoxDriver();
		}
		
		return driver;
	}
}
